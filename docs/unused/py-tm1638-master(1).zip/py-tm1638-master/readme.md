# py-tm1638

Python library for the TM1638 7 segment display with 16 buttons.

This module is commonly sold on deal extreme and eBay, but differs from the version that has 8 LEDs and 8 buttons. The 8 button version is common cathode, the 16 button version is common anode.
